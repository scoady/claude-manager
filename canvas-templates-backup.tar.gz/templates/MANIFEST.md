# Canvas Widget Template Manifest
_Last updated: 2026-03-06T04:27:00.304034+00:00_
_Total templates: 122_

| Project | Widget ID | Title | Collected | File |
|---------|-----------|-------|-----------|------|
| unknown | 2f4d318d | Untitled | unknown | `2f4d318d.json` |
| unknown | 84f7d654 | Untitled | unknown | `84f7d654.json` |
| unknown | agent-constellation | STELLAR COMMAND | unknown | `agent-constellation.json` |
| unknown | b7cf0d2b | Untitled | unknown | `b7cf0d2b.json` |
| unknown | ba84af45 | Untitled | unknown | `ba84af45.json` |
| claude-manager | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `claude-manager--sys-agent-kanban.json` |
| claude-manager | sys-agent-network | Agents | 2026-03-06T04:11:34 | `claude-manager--sys-agent-network.json` |
| claude-manager | sys-task-constellation | Tasks — 19/21 complete | 2026-03-06T04:11:34 | `claude-manager--sys-task-constellation.json` |
| claude-manager-macos | activity-log | Activity Log | 2026-03-06T04:11:34 | `claude-manager-macos--activity-log.json` |
| claude-manager-macos | build-status | Build Pipeline | 2026-03-06T04:11:34 | `claude-manager-macos--build-status.json` |
| claude-manager-macos | project-info | Project Info | 2026-03-06T04:11:34 | `claude-manager-macos--project-info.json` |
| claude-manager-macos | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `claude-manager-macos--sys-agent-kanban.json` |
| claude-manager-macos | sys-agent-network | Agents — 4 active | 2026-03-06T04:11:34 | `claude-manager-macos--sys-agent-network.json` |
| claude-manager-macos | sys-task-constellation | Tasks — 30/31 complete | 2026-03-06T04:11:34 | `claude-manager-macos--sys-task-constellation.json` |
| claude-manager-macos | test-progress | Test Coverage | 2026-03-06T04:11:34 | `claude-manager-macos--test-progress.json` |
| claude-manager-macos | tpl-mmdwxce8 | Live Terminal Feed | 2026-03-06T04:11:34 | `claude-manager-macos--tpl-mmdwxce8.json` |
| claude-manager-macos | tpl-mmdxf56u | Live Terminal Feed | 2026-03-06T04:11:34 | `claude-manager-macos--tpl-mmdxf56u.json` |
| claude-manager-macos | tpl-mmdyvscn | Live Terminal Feed | 2026-03-06T04:11:34 | `claude-manager-macos--tpl-mmdyvscn.json` |
| claude-manager-macos | tpl-mmdyzxdu | Terminal Console | 2026-03-06T04:11:34 | `claude-manager-macos--tpl-mmdyzxdu.json` |
| unknown | claude-terminal | AGENTS | unknown | `claude-terminal.json` |
| helm-platform | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `helm-platform--sys-agent-kanban.json` |
| helm-platform | sys-agent-network | Agents | 2026-03-06T04:11:34 | `helm-platform--sys-agent-network.json` |
| helm-platform | sys-task-constellation | Tasks — 0/0 complete | 2026-03-06T04:11:34 | `helm-platform--sys-task-constellation.json` |
| java-webapp | claude-terminal | AGENTS | 2026-03-06T04:11:34 | `java-webapp--claude-terminal.json` |
| java-webapp | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `java-webapp--sys-agent-kanban.json` |
| jenkins-macos-agent | project-status | Project Status | 2026-03-06T04:11:34 | `jenkins-macos-agent--project-status.json` |
| jenkins-macos-agent | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `jenkins-macos-agent--sys-agent-kanban.json` |
| jenkins-macos-agent | sys-agent-network | Agents | 2026-03-06T04:11:34 | `jenkins-macos-agent--sys-agent-network.json` |
| jenkins-macos-agent | sys-task-constellation | Tasks — 9/9 complete | 2026-03-06T04:11:34 | `jenkins-macos-agent--sys-task-constellation.json` |
| jenkins-macos-agent | task-board | Task Board | 2026-03-06T04:11:34 | `jenkins-macos-agent--task-board.json` |
| jenkins-macos-agent | task-progress | Task Progress | 2026-03-06T04:11:34 | `jenkins-macos-agent--task-progress.json` |
| kind-infra | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `kind-infra--agent-constellation.json` |
| kind-infra | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `kind-infra--claude-terminal.json` |
| kind-infra | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `kind-infra--sys-agent-kanban.json` |
| unknown | ops-terminal | Untitled | unknown | `ops-terminal.json` |
| unknown | progress-bar | Untitled | unknown | `progress-bar.json` |
| python-deployment-poc | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `python-deployment-poc--claude-terminal.json` |
| python-deployment-poc | neon-kanban-tasks | Task Board | 2026-03-06T04:11:34 | `python-deployment-poc--neon-kanban-tasks.json` |
| python-deployment-poc | neon-kanban | TASK BOARD | 2026-03-06T04:12:23 | `python-deployment-poc--neon-kanban.json` |
| python-deployment-poc | sys-agent-kanban | {{PROJECT}} — Agent Pipeline | 2026-03-06T04:12:23 | `python-deployment-poc--sys-agent-kanban.json` |
| remotion-audio-viz | 3ba982b8-7bb1-4d96-b670-f998a6358324 | Audio Visualization — Research Notes | 2026-03-06T04:11:34 | `remotion-audio-viz--3ba982b8-7bb1-4d96-b670-f998a6358324.json` |
| remotion-audio-viz | 44adfb95-4172-46b0-bbbc-a41d0499a216 | Audio Visualization — Tech Stack | 2026-03-06T04:11:34 | `remotion-audio-viz--44adfb95-4172-46b0-bbbc-a41d0499a216.json` |
| remotion-audio-viz | 681d5e2d-a079-4449-9305-456e69b07f10 | Audio Visualization — Demo Preview | 2026-03-06T04:11:34 | `remotion-audio-viz--681d5e2d-a079-4449-9305-456e69b07f10.json` |
| remotion-audio-viz | a9060dac-8953-4480-bb0e-4a5883066eb0 | Audio Visualization — Status | 2026-03-06T04:11:34 | `remotion-audio-viz--a9060dac-8953-4480-bb0e-4a5883066eb0.json` |
| remotion-audio-viz | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-audio-viz--agent-constellation.json` |
| remotion-audio-viz | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-audio-viz--claude-terminal.json` |
| remotion-constellation-capture | 0937343e-1b46-420f-aad4-318e3131ff0c | Constellation Capture — Demo Preview | 2026-03-06T04:11:34 | `remotion-constellation-capture--0937343e-1b46-420f-aad4-318e3131ff0c.json` |
| remotion-constellation-capture | 5b143617-5806-4b4f-a50c-bc3ca429adf8 | Constellation Capture — Status | 2026-03-06T04:11:34 | `remotion-constellation-capture--5b143617-5806-4b4f-a50c-bc3ca429adf8.json` |
| remotion-constellation-capture | 8e536ee0-a120-4db3-8e1b-6d63465e46e4 | Constellation Capture — Tech Stack | 2026-03-06T04:11:34 | `remotion-constellation-capture--8e536ee0-a120-4db3-8e1b-6d63465e46e4.json` |
| remotion-constellation-capture | 8f18bca1-ced4-4757-8156-b14569ff14d9 | Constellation Capture — Research Notes | 2026-03-06T04:11:34 | `remotion-constellation-capture--8f18bca1-ced4-4757-8156-b14569ff14d9.json` |
| remotion-daw-poc | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-daw-poc--agent-constellation.json` |
| remotion-daw-poc | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-daw-poc--claude-terminal.json` |
| remotion-demo-agent-replay | 11d6cf9f-ddb4-48e2-a0e3-04f4a4bd6a7e | Research Notes | 2026-03-06T04:11:34 | `remotion-demo-agent-replay--11d6cf9f-ddb4-48e2-a0e3-04f4a4bd6a7e.json` |
| remotion-demo-agent-replay | 1d3061e1-7c04-425c-89c1-7aff5192c3c3 | Demo Preview | 2026-03-06T04:11:34 | `remotion-demo-agent-replay--1d3061e1-7c04-425c-89c1-7aff5192c3c3.json` |
| remotion-demo-agent-replay | 750f6e25-663d-45fa-9a4c-092a2c5cee68 | Project Status | 2026-03-06T04:11:34 | `remotion-demo-agent-replay--750f6e25-663d-45fa-9a4c-092a2c5cee68.json` |
| remotion-demo-agent-replay | 78c5117b-79c9-43b1-bb42-76ad94f44554 | Tech Stack | 2026-03-06T04:11:34 | `remotion-demo-agent-replay--78c5117b-79c9-43b1-bb42-76ad94f44554.json` |
| remotion-demo-agent-replay | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-demo-agent-replay--agent-constellation.json` |
| remotion-demo-agent-replay | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-demo-agent-replay--claude-terminal.json` |
| remotion-demo-dashboard-recorder | 03869cc8-3421-4ae3-900a-c25c54cb98ff | Demo Preview | 2026-03-06T04:11:34 | `remotion-demo-dashboard-recorder--03869cc8-3421-4ae3-900a-c25c54cb98ff.json` |
| remotion-demo-dashboard-recorder | 7635f47c-52c5-4ae1-8476-bcc26dada95d | Research Notes | 2026-03-06T04:11:34 | `remotion-demo-dashboard-recorder--7635f47c-52c5-4ae1-8476-bcc26dada95d.json` |
| remotion-demo-dashboard-recorder | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-demo-dashboard-recorder--agent-constellation.json` |
| remotion-demo-dashboard-recorder | bb28473d-265b-4bbb-9a99-90ae18e643f5 | Project Status | 2026-03-06T04:11:34 | `remotion-demo-dashboard-recorder--bb28473d-265b-4bbb-9a99-90ae18e643f5.json` |
| remotion-demo-dashboard-recorder | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-demo-dashboard-recorder--claude-terminal.json` |
| remotion-demo-dashboard-recorder | e253507c-79e1-4a1a-81a9-2b8521926643 | Tech Stack | 2026-03-06T04:11:34 | `remotion-demo-dashboard-recorder--e253507c-79e1-4a1a-81a9-2b8521926643.json` |
| remotion-demo-interactive-player | 3e0c6304-0bca-4493-8be3-bc7e7ea40c60 | Interactive Player — Demo Preview | 2026-03-06T04:11:34 | `remotion-demo-interactive-player--3e0c6304-0bca-4493-8be3-bc7e7ea40c60.json` |
| remotion-demo-interactive-player | 61fcf43a-05e7-4a34-b603-48ddd9128fe9 | Interactive Player — Tech Stack | 2026-03-06T04:11:34 | `remotion-demo-interactive-player--61fcf43a-05e7-4a34-b603-48ddd9128fe9.json` |
| remotion-demo-interactive-player | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-demo-interactive-player--agent-constellation.json` |
| remotion-demo-interactive-player | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-demo-interactive-player--claude-terminal.json` |
| remotion-demo-interactive-player | de1596da-3565-42c5-81cb-cb9a9c4d12b3 | Interactive Player — Research Notes | 2026-03-06T04:11:34 | `remotion-demo-interactive-player--de1596da-3565-42c5-81cb-cb9a9c4d12b3.json` |
| remotion-demo-interactive-player | fbce581c-3f73-4ba5-ae2e-bf665690adde | Interactive Player — Status | 2026-03-06T04:11:34 | `remotion-demo-interactive-player--fbce581c-3f73-4ba5-ae2e-bf665690adde.json` |
| remotion-demos | activity-log | Activity Log | 2026-03-06T04:25:29 | `remotion-demos--activity-log.json` |
| remotion-demos | agent-constellation | STELLAR COMMAND | 2026-03-06T04:24:59 | `remotion-demos--agent-constellation.json` |
| remotion-demos | claude-terminal | AGENTS | 2026-03-06T04:24:59 | `remotion-demos--claude-terminal.json` |
| remotion-demos | task-board | Task Board | 2026-03-06T04:25:29 | `remotion-demos--task-board.json` |
| remotion-demos | task-progress | Build Progress | 2026-03-06T04:25:29 | `remotion-demos--task-progress.json` |
| remotion-experiments | 07d2b5ae-085d-4842-8ca2-301ec715c6cc | Agent Activity | 2026-03-06T04:11:34 | `remotion-experiments--07d2b5ae-085d-4842-8ca2-301ec715c6cc.json` |
| remotion-experiments | 15642d3f-f8c4-4865-a8b0-4c364c634958 | Remotion Subprojects Master Status | 2026-03-06T04:11:34 | `remotion-experiments--15642d3f-f8c4-4865-a8b0-4c364c634958.json` |
| remotion-experiments | 1beb672c-9361-4419-a998-5f3d8aa98415 | Remotion Demo Projects | 2026-03-06T04:11:34 | `remotion-experiments--1beb672c-9361-4419-a998-5f3d8aa98415.json` |
| remotion-experiments | 1e8bfad4-a521-4094-ace0-ea663d745f9c | L-SYSTEM GROWTH | 2026-03-06T04:16:57 | `remotion-experiments--1e8bfad4-a521-4094-ace0-ea663d745f9c.json` |
| remotion-experiments | 2211625b-98b1-415d-955e-ab04a9360fca | Remotion Demo Progress | 2026-03-06T04:11:34 | `remotion-experiments--2211625b-98b1-415d-955e-ab04a9360fca.json` |
| remotion-experiments | 28f35ffa-d821-4781-b3a1-57a131eac433 | test | 2026-03-06T04:11:34 | `remotion-experiments--28f35ffa-d821-4781-b3a1-57a131eac433.json` |
| remotion-experiments | 29bab746-cd58-4239-ac74-55b5291f7d85 | Milestone Tracker | 2026-03-06T04:11:34 | `remotion-experiments--29bab746-cd58-4239-ac74-55b5291f7d85.json` |
| remotion-experiments | 480e0c3a-76f6-4553-8199-8fd8556a1381 | Remotion Demo Progress | 2026-03-06T04:11:34 | `remotion-experiments--480e0c3a-76f6-4553-8199-8fd8556a1381.json` |
| remotion-experiments | 60b1fc62-c47d-45c8-b4c7-f2c599fe5d3a | Remotion x Agent Orchestration | 2026-03-06T04:11:34 | `remotion-experiments--60b1fc62-c47d-45c8-b4c7-f2c599fe5d3a.json` |
| remotion-experiments | 6cc6a72e-dcab-4939-8233-6ca8d9d7911b | PROJECT STATUS | 2026-03-06T04:12:04 | `remotion-experiments--6cc6a72e-dcab-4939-8233-6ca8d9d7911b.json` |
| remotion-experiments | 7c88acc4-ab49-4f08-bd2e-1284c9d5dfe3 | GENERATIVE ART | 2026-03-06T04:14:54 | `remotion-experiments--7c88acc4-ab49-4f08-bd2e-1284c9d5dfe3.json` |
| remotion-experiments | 7e2c0aac-f8ad-44f2-bed8-46d9103802a0 | REACTION-DIFFUSION | 2026-03-06T04:17:27 | `remotion-experiments--7e2c0aac-f8ad-44f2-bed8-46d9103802a0.json` |
| remotion-experiments | 7e94073c-a4c9-40c4-85d3-f03f8847288d | TECH MATRIX | 2026-03-06T04:17:58 | `remotion-experiments--7e94073c-a4c9-40c4-85d3-f03f8847288d.json` |
| remotion-experiments | 93409132-a952-4560-92d9-37f030f3457d | Cleanup Standards | 2026-03-06T04:11:34 | `remotion-experiments--93409132-a952-4560-92d9-37f030f3457d.json` |
| remotion-experiments | 9ebed948-212a-42b7-abac-af59e2d982fc | Remotion Research Findings | 2026-03-06T04:11:34 | `remotion-experiments--9ebed948-212a-42b7-abac-af59e2d982fc.json` |
| remotion-experiments | a7c6423c-be54-4fd9-9899-9dd843b0a0e3 | Task Board | 2026-03-06T04:12:23 | `remotion-experiments--a7c6423c-be54-4fd9-9899-9dd843b0a0e3.json` |
| remotion-experiments | activity-feed | Activity Feed | 2026-03-06T04:12:23 | `remotion-experiments--activity-feed.json` |
| remotion-experiments | agent-constellation | AGENT CONSTELLATION | 2026-03-06T04:12:23 | `remotion-experiments--agent-constellation.json` |
| remotion-experiments | b3c798e9-5444-4856-91cd-01f3356d9f24 | Remotion Demo Projects | 2026-03-06T04:11:34 | `remotion-experiments--b3c798e9-5444-4856-91cd-01f3356d9f24.json` |
| remotion-experiments | b813dfbe-41c3-4a8f-b427-3c01bd82ffd7 | Remotion Demo Progress | 2026-03-06T04:11:34 | `remotion-experiments--b813dfbe-41c3-4a8f-b427-3c01bd82ffd7.json` |
| remotion-experiments | c2ecbe31-1a8b-4c46-884c-0f4bb3b8bd16 | SHADER ART | 2026-03-06T04:12:04 | `remotion-experiments--c2ecbe31-1a8b-4c46-884c-0f4bb3b8bd16.json` |
| remotion-experiments | cd8615b1-f017-4197-9db4-4d2e92ebaa8d | VORONOI | 2026-03-06T04:17:58 | `remotion-experiments--cd8615b1-f017-4197-9db4-4d2e92ebaa8d.json` |
| remotion-experiments | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-experiments--claude-terminal.json` |
| remotion-experiments | dashboard-controller-status | Dashboard Controller | 2026-03-06T04:20:58 | `remotion-experiments--dashboard-controller-status.json` |
| remotion-experiments | e6ed0d25-e369-4313-9f7c-6a46292a126f | Tasks Completed | 2026-03-06T04:12:23 | `remotion-experiments--e6ed0d25-e369-4313-9f7c-6a46292a126f.json` |
| remotion-experiments | f6a45f6f-1fd3-4249-93a2-ff1d35c46e0c | REMOTION RESEARCH | 2026-03-06T04:12:23 | `remotion-experiments--f6a45f6f-1fd3-4249-93a2-ff1d35c46e0c.json` |
| remotion-experiments | fbdb2e52-c184-454b-ac2e-617ef99c3e3b | Animation Techniques Showcase | 2026-03-06T04:12:54 | `remotion-experiments--fbdb2e52-c184-454b-ac2e-617ef99c3e3b.json` |
| remotion-experiments | sys-agent-kanban | Agent Pipeline | 2026-03-06T04:12:23 | `remotion-experiments--sys-agent-kanban.json` |
| remotion-experiments | sys-agent-network | Agents | 2026-03-06T04:11:34 | `remotion-experiments--sys-agent-network.json` |
| remotion-experiments | sys-task-constellation | Tasks — 19/21 complete | 2026-03-06T04:11:34 | `remotion-experiments--sys-task-constellation.json` |
| remotion-experiments | task-progress | Task Progress | 2026-03-06T04:11:34 | `remotion-experiments--task-progress.json` |
| remotion-generative-art | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-generative-art--agent-constellation.json` |
| remotion-generative-art | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-generative-art--claude-terminal.json` |
| remotion-player-widget | 60e622a5-8ea7-47a7-9fff-21d558b8313a | Player Widget — Research Notes | 2026-03-06T04:11:34 | `remotion-player-widget--60e622a5-8ea7-47a7-9fff-21d558b8313a.json` |
| remotion-player-widget | 7b482b9a-9127-44e8-a66a-a11da77f65a8 | Player Widget — Demo Preview | 2026-03-06T04:11:34 | `remotion-player-widget--7b482b9a-9127-44e8-a66a-a11da77f65a8.json` |
| remotion-player-widget | a2be4e32-7950-4418-b1e1-46cd1de7578e | Player Widget — Status | 2026-03-06T04:11:34 | `remotion-player-widget--a2be4e32-7950-4418-b1e1-46cd1de7578e.json` |
| remotion-player-widget | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-player-widget--agent-constellation.json` |
| remotion-player-widget | c68c3f17-8f37-43c4-b43f-38ea613a34f4 | Player Widget — Tech Stack | 2026-03-06T04:11:34 | `remotion-player-widget--c68c3f17-8f37-43c4-b43f-38ea613a34f4.json` |
| remotion-player-widget | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-player-widget--claude-terminal.json` |
| remotion-sprint-summary | 41afca44-3ea9-4af5-a8d4-625583c60926 | Sprint Summary — Demo Preview | 2026-03-06T04:11:34 | `remotion-sprint-summary--41afca44-3ea9-4af5-a8d4-625583c60926.json` |
| remotion-sprint-summary | 43096fb3-1ae0-4ee9-9c9b-8c614e53f05e | Sprint Summary — Status | 2026-03-06T04:11:34 | `remotion-sprint-summary--43096fb3-1ae0-4ee9-9c9b-8c614e53f05e.json` |
| remotion-sprint-summary | 6333aaa3-29b7-4721-9fe4-3c19b14ed049 | Sprint Summary — Tech Stack | 2026-03-06T04:11:34 | `remotion-sprint-summary--6333aaa3-29b7-4721-9fe4-3c19b14ed049.json` |
| remotion-sprint-summary | 65f8214b-a9b0-463c-ae03-867aa165ed71 | Sprint Summary — Tech Stack | 2026-03-06T04:11:34 | `remotion-sprint-summary--65f8214b-a9b0-463c-ae03-867aa165ed71.json` |
| remotion-sprint-summary | agent-constellation | STELLAR COMMAND | 2026-03-06T04:12:23 | `remotion-sprint-summary--agent-constellation.json` |
| remotion-sprint-summary | c19d3ba8-f455-45b8-9824-e0b144f585ab | Sprint Summary — Research Notes | 2026-03-06T04:11:34 | `remotion-sprint-summary--c19d3ba8-f455-45b8-9824-e0b144f585ab.json` |
| remotion-sprint-summary | claude-terminal | AGENTS | 2026-03-06T04:12:23 | `remotion-sprint-summary--claude-terminal.json` |
| unknown | task-kanban | TASKS | unknown | `task-kanban.json` |
