#!/usr/bin/env python3
"""
Background template collector.
Polls all project canvases every 30 seconds and saves new/updated widgets
as reusable template JSON files.
"""

import json
import os
import re
import sys
import time
import hashlib
import urllib.request
import urllib.parse
from datetime import datetime, timezone

# Unbuffered stdout for background execution
sys.stdout.reconfigure(line_buffering=True)

API_BASE = "http://localhost:4040/api"
TEMPLATE_DIR = os.path.expanduser("~/.claude/canvas/templates")
MANIFEST_PATH = os.path.join(TEMPLATE_DIR, "MANIFEST.md")
ITERATIONS = 30
INTERVAL = 30  # seconds

# Track content hashes to detect updates
hash_cache = {}


def api_get(path):
    """GET from the API, return parsed JSON or None on failure."""
    try:
        url = f"{API_BASE}{urllib.parse.quote(path)}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"  [WARN] GET {path} failed: {e}")
        return None


def content_hash(widget):
    """Hash the meaningful content of a widget for change detection."""
    relevant = json.dumps({
        k: widget.get(k)
        for k in ("title", "html", "css", "js", "template_id", "data")
    }, sort_keys=True)
    return hashlib.md5(relevant.encode()).hexdigest()


def templatize(text, project_name):
    """Replace project-specific references with {{PROJECT}} placeholder."""
    if not text or not project_name:
        return text
    # Replace the project name (case-insensitive, whole-word-ish)
    result = re.sub(re.escape(project_name), "{{PROJECT}}", text, flags=re.IGNORECASE)
    return result


def save_widget(project_name, widget):
    """Save a widget as a template JSON file if new or changed."""
    wid = widget.get("id", "unknown")
    filename = f"{project_name}--{wid}.json"
    filepath = os.path.join(TEMPLATE_DIR, filename)

    h = content_hash(widget)
    cache_key = f"{project_name}/{wid}"

    # Check if we already have this exact content
    if cache_key in hash_cache and hash_cache[cache_key] == h:
        return False  # no change

    # Also check on-disk file hash if not in cache yet
    if cache_key not in hash_cache and os.path.exists(filepath):
        try:
            with open(filepath, "r") as f:
                existing = json.load(f)
            existing_h = content_hash(existing)
            if existing_h == h:
                hash_cache[cache_key] = h
                return False
        except Exception:
            pass

    # Templatize content fields
    template = dict(widget)
    for field in ("html", "css", "js", "title"):
        if template.get(field):
            template[field] = templatize(template[field], project_name)

    template["_source_project"] = project_name
    template["_collected_at"] = datetime.now(timezone.utc).isoformat()

    with open(filepath, "w") as f:
        json.dump(template, f, indent=2)

    hash_cache[cache_key] = h
    print(f"  [SAVED] {filename}")
    return True


def update_manifest():
    """Rebuild the MANIFEST.md from all saved template files."""
    templates = []
    for fname in sorted(os.listdir(TEMPLATE_DIR)):
        if not fname.endswith(".json") or fname == "collector.py":
            continue
        fpath = os.path.join(TEMPLATE_DIR, fname)
        try:
            with open(fpath, "r") as f:
                data = json.load(f)
            templates.append({
                "file": fname,
                "project": data.get("_source_project", "unknown"),
                "widget_id": data.get("id", "unknown"),
                "title": data.get("title", "Untitled"),
                "collected_at": data.get("_collected_at", "unknown"),
            })
        except Exception:
            continue

    lines = [
        "# Canvas Widget Template Manifest",
        f"_Last updated: {datetime.now(timezone.utc).isoformat()}_",
        f"_Total templates: {len(templates)}_",
        "",
        "| Project | Widget ID | Title | Collected | File |",
        "|---------|-----------|-------|-----------|------|",
    ]
    for t in templates:
        lines.append(
            f"| {t['project']} | {t['widget_id']} | {t['title']} | {t['collected_at'][:19]} | `{t['file']}` |"
        )
    lines.append("")

    with open(MANIFEST_PATH, "w") as f:
        f.write("\n".join(lines))


def poll_once():
    """One full polling cycle across all projects."""
    projects = api_get("/projects")
    if not projects:
        print("  No projects returned or API unavailable.")
        return 0

    saved_count = 0
    for proj in projects:
        name = proj if isinstance(proj, str) else proj.get("name", "")
        if not name:
            continue

        canvas = api_get(f"/canvas/{name}")
        if not canvas:
            continue

        widgets = canvas if isinstance(canvas, list) else canvas.get("widgets", [])
        for w in widgets:
            if save_widget(name, w):
                saved_count += 1

    if saved_count > 0:
        update_manifest()

    return saved_count


def main():
    print(f"Template collector starting — {ITERATIONS} iterations, {INTERVAL}s interval")
    print(f"Output dir: {TEMPLATE_DIR}")
    print()

    # Build initial hash cache from existing files
    for fname in os.listdir(TEMPLATE_DIR):
        if fname.endswith(".json"):
            fpath = os.path.join(TEMPLATE_DIR, fname)
            try:
                with open(fpath, "r") as f:
                    data = json.load(f)
                proj = data.get("_source_project", "")
                wid = data.get("id", "")
                if proj and wid:
                    hash_cache[f"{proj}/{wid}"] = content_hash(data)
            except Exception:
                pass

    total_saved = 0
    for i in range(1, ITERATIONS + 1):
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] Poll {i}/{ITERATIONS}...")
        saved = poll_once()
        total_saved += saved
        if saved:
            print(f"  -> {saved} new/updated template(s)")
        else:
            print(f"  -> no changes")

        if i < ITERATIONS:
            time.sleep(INTERVAL)

    # Final manifest rebuild
    update_manifest()
    print(f"\nDone. Total templates saved/updated: {total_saved}")
    print(f"Manifest: {MANIFEST_PATH}")


if __name__ == "__main__":
    main()
